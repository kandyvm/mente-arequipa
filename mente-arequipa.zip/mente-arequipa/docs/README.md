# Documentación

- `capturas/`: pantallas del prototipo diseñado en Google Stitch.
  - Figura 1: inicio de sesión.
  - Figura 2: dashboard del orientador.
  - Figura 3: nueva solicitud.
  - Figura 4: derivación asistida.
  - Figura 5: consulta pública.
  - Figura 8: diagrama de arquitectura.
- Agregar aquí el documento de Fases 1 y 2 (PDF).
