# Backend (Laravel 12)

API REST de MENTE Arequipa. El proyecto Laravel se agrega aquí en la semana 12.
