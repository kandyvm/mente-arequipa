# Frontend (Vue 3)

SPA de MENTE Arequipa con Vue 3, Vite y Tailwind CSS. El proyecto se agrega aquí en la semana 12.
